if (__develop === true) {
  (function() {
    var $ = require('/js/lib/jquery');
    var ajax = $.ajax;
    $.ajax = function(config) {
      config.url = '/proxy?url=' + window.encodeURIComponent(config.url);
      ajax(config);
    };
  })();
}

var $ = require('/js/lib/jquery');

alert('new project');