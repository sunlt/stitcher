var util = require('./util');

function Queue(){
	this.taskList = [];
}
Queue.prototype.add = function (fn,scope){
	scope = scope || this;
	this.taskList.push(util.bind(fn,scope));
};
Queue.prototype.next = function (param){
	var fn = this.taskList.shift();
	if(!!fn){
		fn(param);
	}
};
Queue.prototype.wait = function (msec){
	var callback = function (){
		this.next();
	};
	this.add(function (){
		window.setTimeout(util.bind(callback,this),msec);
	},this);
};
Queue.prototype.start = function (){
	this.next();
};

Queue.prototype.clear = function (){
	this.taskList = [];
};

exports = module.exports = Queue;