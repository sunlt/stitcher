var util = {};

util.UUIDMap = {};
util.createUUID = function(name) {
	var id = util.UUIDMap[name] = util.UUIDMap[name] || 0;
	id++;
	util.UUIDMap[name] = id;
	return name + '_' + id;
};

util.get = function(id) {
	return document.getElementById(id);
};
util.extend = function(child, parent) {
	for (var key in parent) {
		if (parent.hasOwnProperty(key)) child[key] = parent[key];
	}

	function ctor() {
		this.constructor = child;
	}
	ctor.prototype = parent.prototype;
	child.prototype = new ctor;
	child.__super__ = parent.prototype;
	return child;
};

util.apply = function(obj, props) {
	for (var key in props) {
		if (props.hasOwnProperty(key) && typeof props[key] != 'undefined') obj[key] = props[key];
	}
	return obj;
};

util.bind = function(func, self) {
	var context = self || win;
	if (arguments.length > 2) {
		var args = Array.prototype.slice.call(arguments, 2);
		return function() {
			var newArgs = Array.prototype.concat.apply(args, arguments);
			return func.apply(context, newArgs);
		};
	} else {
		return function() {
			return func.apply(context, arguments);
		};
	}
};


util.ns = function(name, context) {
	context = context || window;
	var parts = name.split("."),
		obj = context;
	for (var i = 0; i < parts.length; i++) {
		var p = parts[i];
		obj = obj[p] || (obj[p] = {});
	}
	return obj;
};

function detectBrowser(ns) {
	var ua = ns.ua = navigator.userAgent;
	ns.isWebKit = (/webkit/i).test(ua);
	ns.isMozilla = (/mozilla/i).test(ua);
	ns.isIE = (/msie/i).test(ua);
	ns.isFirefox = (/firefox/i).test(ua);
	ns.isChrome = (/chrome/i).test(ua);
	ns.isSafari = (/safari/i).test(ua) && !this.isChrome;
	ns.isMobile = (/mobile/i).test(ua);
	ns.isOpera = (/opera/i).test(ua);
	ns.isIOS = (/ios/i).test(ua);
	ns.isIpad = (/ipad/i).test(ua);
	ns.isIpod = (/ipod/i).test(ua);
	ns.isIphone = (/iphone/i).test(ua) && !this.isIpod;
	ns.isAndroid = (/android/i).test(ua);
	ns.supportStorage = "localStorage" in window;
	ns.supportOrientation = "orientation" in window;
	ns.supportDeviceMotion = "ondevicemotion" in window;
	ns.supportTouch = "ontouchstart" in window;
	ns.supportTransform3d = ('WebKitCSSMatrix' in window);
	ns.cssPrefix = ns.isWebKit ? "webkit" : ns.isFirefox ? "Moz" : ns.isOpera ? "O" : ns.isIE ? "ms" : "";
};
detectBrowser(util);

util.bind = function(fn) {
	var __method = fn;
	var args = Array.prototype.slice.call(arguments, 1);
	var object = args.shift();
	return function() {
		return __method.apply(object, args.concat(Array.prototype.slice.call(arguments)));
	}
};

var head = document.getElementsByTagName('head')[0];
var metas = head.getElementsByTagName("meta");
var metaAfterNode = metas.length > 0 ? metas[metas.length - 1].nextSibling : head.childNodes[0];
/**
 * 动态添加meta到head中。
 */
util.addMeta = function(props) {
	var meta = document.createElement("meta");
	for (var p in props)
	meta.setAttribute(p, props[p]);
	head.insertBefore(meta, metaAfterNode);
};

util.emptyFn = function() {};

util.decode = function(str) {
	return JSON.parse(str);
};

util.encode = function(o) {
	return JSON.stringify(o);
};

util.urlEncode = function(o) {
	var params = [];
	for (var k in o) {
		if (o.hasOwnProperty(k)) {
			params.push(encodeURIComponent(k) + '=' + encodeURIComponent(o[k]));
		}
	}
	return params.join('&');
};

util.urlDecode = function(str) {
	var result = {};
	var arr = str.split('&');
	for (var i = 0, l = arr.length; i < l; i++) {
		var kv = arr[i].split('=');
		result[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1]);
	}
	return result;
};

util.urlAppend = function(url, s) {
	return url + (url.indexOf('?') === -1 ? '?' : '&') + s;
};

util.getUrlParams = function() {
	return util.urlDecode(window.location.search.slice(1));
};

var formatRegExp = /%[sdj%]/g;
util.format = function(f) {
	if (typeof f !== 'string') {
		var objects = [];
		for (var i = 0; i < arguments.length; i++) {
			objects.push(inspect(arguments[i]));
		}
		return objects.join(' ');
	}

	var i = 1;
	var args = arguments;
	var len = args.length;
	var str = String(f).replace(formatRegExp, function(x) {
		if (i >= len) return x;
		switch (x) {
		case '%s':
			return String(args[i++]);
		case '%d':
			return Number(args[i++]);
		case '%j':
			return JSON.stringify(args[i++]);
		case '%%':
			return '%';
		default:
			return x;
		}
	});
	for (var x = args[i]; i < len; x = args[++i]) {
		if (x === null || typeof x !== 'object') {
			str += ' ' + x;
		} else {
			str += ' ' + inspect(x);
		}
	}
	return str;
};

util.expand = function(root, name) {
	var results = [],
		parts, part;
	if (/^\.\.?(\/|$)/.test(name)) {
		parts = [root, name].join('/').split('/');
	} else {
		parts = name.split('/');
	}
	for (var i = 0, length = parts.length; i < length; i++) {
		part = parts[i];
		if (part == '..') {
			results.pop();
		} else if (part != '.' && part != '') {
			results.push(part);
		}
	}
	return results.join('/');
};

util.log = function(o) {
	if ( !! console && !! console.log) {
		console.log(o);
	}
};

util.formatTime = function(millisecond) {
	var str = '';
	var date = new Date(millisecond);
	var m = date.getMinutes();
	var s = date.getSeconds();
	str = (m < 10 ? '0' + m : m) + ':' + (s < 10 ? '0' + s : s);
	return str;
};

util.ns('array', util);

util.array.find = function(list, fun, scope) {
	scope = scope || this;
	for (var i = list.length - 1; i >= 0; i--) {
		var item = list[i];
		if (fun.call(scope, item) === true) {
			return item;
		}
	};
	return null;
};

util.array.remove = function(array, from, to) {
	var rest = array.slice((to || from) + 1 || array.length);
	array.length = from < 0 ? array.length + from : from;
	return array.push.apply(array, rest);
};

util.array.indexOf = function(list, fun, scope) {
	scope = scope || this;
	for (var i = 0, l = list.length; i < l; i++) {
		var item = list[i];
		if (fun.call(scope, item) === true) {
			return i;
		}
	}
	return -1;
};

util.array.shuffle = function(v) {
	for (var j, x, i = v.length; i; j = parseInt(Math.random() * i), x = v[--i], v[i] = v[j], v[j] = x);
	return v;
};

exports = module.exports = util;